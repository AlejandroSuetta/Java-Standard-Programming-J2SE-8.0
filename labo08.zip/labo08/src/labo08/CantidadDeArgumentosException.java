package labo08;

public class CantidadDeArgumentosException extends Exception{
    private String id;
    private String ivelDeError;
    private String mensajeError;

    public CantidadDeArgumentosException(String id, String ivelDeError, String mensajeError) {
        this.id = id;
        this.ivelDeError = ivelDeError;
        this.mensajeError = mensajeError;
    }

    @Override
    public String toString() {
        return "CantidadDeArgumentosException{" + "id=" + id + ", ivelDeError=" + ivelDeError + ", mensajeError=" + mensajeError + '}';
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIvelDeError() {
        return ivelDeError;
    }

    public void setIvelDeError(String ivelDeError) {
        this.ivelDeError = ivelDeError;
    }

    public String getMensajeError() {
        return mensajeError;
    }

    public void setMensajeError(String mensajeError) {
        this.mensajeError = mensajeError;
    }
    
    
}
