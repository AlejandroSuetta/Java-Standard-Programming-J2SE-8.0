package labo08;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Labo08 {
    
    public Labo08() {   /* Esto es la clase Programa */     
    }

    public static void main(String[] args) {
        try {
            if (args.length != 2) {
                throw new CantidadDeArgumentosException("001", "Alto", "Solo deve ingresar dos valores de indole numerica");
            }
            
            int a = Integer.parseInt(args[0]);
            
            int b = Integer.parseInt(args[1]);
            
            Calculo(a, b);
        }
        catch (CantidadDeArgumentosException e) {
            System.out.println(e.getMensajeError());
        }
        catch (NumberFormatException e) {
            System.out.println("Los valores ingresados deven ser numeros");
        }
        catch (Exception e) {
            System.out.println("Se produjo un error inesperado");
        }
        
    }
    
    public static float Calculo (int a, int b) throws Exception{
        if (b == 0) {
            throw new Exception ("El segundo número no puede ser 0");
        }        
        return a/b;
    }
}
