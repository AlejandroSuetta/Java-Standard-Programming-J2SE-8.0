package j2se_labo2;

public class J2se_labo2 {
    
    public static void main(String[] args, int a1, int a2, int a3) 
    {
        int vecNumeros[] = {11, -22, 33, -44, 55, -66, 77, -88, 99};
        int[] vecPositivos = new int [9];
        int[] vecNegativos = new int [9];
        
        for (int a = 0; a < vecNumeros.length; a++)
        {    
        if (vecNumeros[a]>0) System.arraycopy(vecNumeros, a, vecPositivos, a, 1);
        
        else if (vecNumeros[a]<0) System.arraycopy(vecNumeros, a, vecNegativos, a, 1);
        }
        
        int totalposivivos = 0;
        
        for (int a = 0; a < vecPositivos.length; a++)
        {
            totalposivivos = totalposivivos + vecPositivos [a];
        }
        
        int negativos = 0;
        
        for (int a = 0; a < vecNegativos.length; a++)
        {
            negativos = negativos + vecNegativos [a];
        }

        for (int a = 0; a < vecNumeros.length; a++) System.out.print(vecNumeros[a]);
        System.out.println();
        for (int a = 0; a < vecPositivos.length; a++) System.out.print(vecPositivos[a]);
        System.out.println();
        for (int a = 0; a < vecNegativos.length; a++) System.out.print(vecNegativos[a]);
        System.out.println();
        System.out.println(totalposivivos);
        System.out.println(negativos);

        a1 = 1000;
        a2 = 2000;
        a3 = 300;
        System.out.println(a1);
        System.out.println(a2);
        System.out.println(a3);
    }
    
}
