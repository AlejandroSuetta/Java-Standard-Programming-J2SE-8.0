package labo07;

import java.util.ArrayList;

public class ImpresorDeClientes {
    public static void main(String[] args) {
        Cliente c1 = new Cliente ("Hola", "Mitre");
        Cliente c2 = new Cliente ("Hallo", "SAn Martin");
        Cliente c3 = new Cliente ("Hello", "Belgrano");
        Cliente c4 = new Cliente ("Aloha", "Saavedra");
        Cliente c5 = new Cliente ("Nihao", "Peron");
        
        
        ArrayList<Cliente> losClientes = new ArrayList<Cliente>(5);
        losClientes.add(c1);
        losClientes.add(c2);
        losClientes.add(c3);
        losClientes.add(c4);
        losClientes.add(c5);     
        
        for (Cliente cliente : losClientes) {
            System.out.println(cliente);
        }
    }
}
