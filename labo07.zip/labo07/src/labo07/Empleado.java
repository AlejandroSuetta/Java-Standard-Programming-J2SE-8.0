package labo07;

import java.util.ArrayList;

public class Empleado {
    private String nombre;
    private String dni;
    private int edad;

    public Empleado(String nombre, String dni, int edad) {
        this.nombre = nombre;
        this.dni = dni;
        this.edad = edad;
    }
    
    public static void informarDatosDeEmpleados (ArrayList empleados) {
        for (Object empleado : empleados) {
            System.out.println(empleado);
        }
    }
    
    

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", dni=" + dni + ", edad=" + edad + '}';
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    public int getEdad() {
        return edad;
    }
    
}
