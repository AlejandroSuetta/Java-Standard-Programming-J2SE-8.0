package labo07;

import java.util.ArrayList;
import java.util.List;
import static labo07.Labo07.obtenerEmpleadosMenosDe30;

public class Labo07 {

    public static void main(String[] args) {
        Empleado e1 = new Empleado("Alejandro", "85421536", 24);
        Empleado e2 = new Empleado("Adrian", "2152365", 24);
        Empleado e3 = new Empleado("Alicia", "8541236", 60);
        Empleado e4 = new Empleado("Oscar", "0212121", 68);
        Empleado e5 = new Empleado("Antonio", "9632587", 35);
        Empleado e6 = new Empleado("Carlos", "0147852", 40);
        
        ArrayList<Empleado> empleados = new ArrayList (6);
        empleados.add(e1);
        empleados.add(e2);
        empleados.add(e3);
        empleados.add(e4);
        empleados.add(e5);
        empleados.add(e6);
        
        for(Empleado empleado : empleados) {
            System.out.println(empleado);
        }
        System.out.println("----------------------------------------------------");
        
        System.out.println(empleados.size());   
        System.out.println("----------------------------------------------------");
                
        for (Empleado empleado : empleados) {
            if (empleado.getEdad() < 30) System.out.println(empleado);
        }
        System.out.println("----------------------------------------------------");
        
        Empleado.informarDatosDeEmpleados(empleados);
        System.out.println("----------------------------------------------------");
        
        Empleado.informarDatosDeEmpleados(obtenerEmpleadosMenosDe30(empleados));
    }
    
    public static ArrayList obtenerEmpleadosMenosDe30(ArrayList empleados) {
        // Instancia el arrayList empleadosMenores
        ArrayList empleadosMenores = new ArrayList();

        // Recorre losEmpleados y obtiene los que son menores a 30 años
        for (int indice = 0; indice < empleados.size(); indice++) {
            // Obtiene el objeto y lo castea a un objeto empleado
            Empleado unEmpleado = (Empleado) empleados.get(indice);

            // Si el empleado tiene menos de 30 años, lo selecciona
            if (unEmpleado.getEdad() < 30) {
                empleadosMenores.add(unEmpleado);
            }

        }

        return empleadosMenores;
    }
    
}
