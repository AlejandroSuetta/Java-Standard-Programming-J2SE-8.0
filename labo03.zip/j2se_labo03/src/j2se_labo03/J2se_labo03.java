package j2se_labo03;

public class J2se_labo03 {

    public static void main(String[] args) {
        
    }
    
}
