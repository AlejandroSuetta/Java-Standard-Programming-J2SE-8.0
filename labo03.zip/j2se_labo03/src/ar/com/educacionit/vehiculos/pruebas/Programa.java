package ar.com.educacionit.vehiculos.pruebas;

import ar.com.educacionit.base.entidades.Persona;
import ar.com.educacionit.base.entidades.Vehiculo;
import ar.com.educacionit.vehiculos.entidades.Autos;
import ar.com.educacionit.vehiculos.entidades.Comprador;
import ar.com.educacionit.vehiculos.entidades.Vendedor;

public class Programa {
    public static void main(String[] args) {
        /*Vehiculo vehiculo1 = new Vehiculo (49, 73, 175);
        System.out.println(vehiculo1);
        Persona persona1 = new Persona("Alejandro", "Suetta", "10945204");
        System.out.println(persona1);*/
        
        System.out.println("-- autos1 --");
        Autos autos1 = new Autos("Chevrolet", "Corvett C6", "Naranja", 49, 73, 175);
    
        System.out.println(autos1);
        
        System.out.println("-- comprador1 --");
        Comprador comprador1 = new Comprador(130000, "Alejandro", "Suetta", "10945204");
        
        System.out.println(comprador1);
        
        System.out.println("-- vendedor1 --");
        Vendedor vendedor1 = new Vendedor (20, "Adrian", "Suetta", "40254901");
        
        System.out.println(vendedor1);
        
        
    }
}
