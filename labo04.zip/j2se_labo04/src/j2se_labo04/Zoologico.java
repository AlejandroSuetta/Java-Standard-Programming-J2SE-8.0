package j2se_labo04;

public class Zoologico {
    public final int CANTIDAD_ANIMALES = 25;
    public final int RACIONES_POR_ANIMAL = 5;
    private boolean abierto;
    
    public void abrir(boolean abierto) {
        if (abierto == false){
            System.out.println("Abriendo");
            setAbierto(true);
        }
        
        else System.out.println("Ya esta abierto");
    }
    
    public void alimentarAnimales(int cantidadDeRaciones) {
        if (RACIONES_POR_ANIMAL * CANTIDAD_ANIMALES < cantidadDeRaciones) System.out.println("No es sufuciente");
        else System.out.println("Es suficiente");        
    }
    
    public void cerrar(boolean abierto) {
        if (abierto == true){
            System.out.println("Cerrando");
            setAbierto(false);
        }
        
        else System.out.println("Ya esta cerrado");
    }

    public Zoologico(boolean abierto) {
        this.abierto = abierto;
    }

    public boolean isAbierto()              { return abierto; }
    public void setAbierto(boolean abierto) { this.abierto = abierto; }

    @Override
    public String toString() {
        return "Zoologico{" + "CANTIDAD_ANIMALES=" + CANTIDAD_ANIMALES + ", RACIONES_POR_ANIMAL=" + RACIONES_POR_ANIMAL + ", abierto=" + abierto + '}';
    }
}
