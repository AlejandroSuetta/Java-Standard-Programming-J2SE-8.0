package j2se_labo04;

import java.util.Date;

class Cuidador extends Persona{
    private int cantidadDeRaciones;   
    
    public void alimentarAnimales(int RACIONES_POR_ANIMAL, int CANTIDAD_ANIMALES) {
        if (RACIONES_POR_ANIMAL * CANTIDAD_ANIMALES < cantidadDeRaciones) System.out.println("No es sufuciente");
        else System.out.println("Es suficiente");
    }

    public Cuidador(int cantidadDeRaciones, String nombre, String fechaDeNacimiento) {
        super(nombre, fechaDeNacimiento);
        this.cantidadDeRaciones = cantidadDeRaciones;
    }

    public int getCantidadDeRaciones()                          { return cantidadDeRaciones; }
    public void setCantidadDeRaciones(int cantidadDeRaciones)   { this.cantidadDeRaciones = cantidadDeRaciones; }

    @Override
    public String toString() {
        return super.toString() + "Cuidador{" + "cantidadDeRaciones=" + cantidadDeRaciones + '}';
    }  
}
