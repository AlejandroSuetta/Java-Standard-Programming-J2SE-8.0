package j2se_labo04;

public class J2se_labo04 {

    public static void main(String[] args) {
        Cuidador cuidador1 = new Cuidador(120, "Sergio", "2018-05-24");
        
        Zoologico zoologico1 = new Zoologico(false);
        
        zoologico1.abrir(false);
        zoologico1.alimentarAnimales(120);
        zoologico1.cerrar(false);
    }
}
    
