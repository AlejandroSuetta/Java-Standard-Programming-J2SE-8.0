/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Suetta
 */
public class VentanaController implements Initializable {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApellido;
    @FXML
    private ComboBox<?> cmbSexo;
    @FXML
    private ComboBox<?> cmbECivil;
    @FXML
    private CheckBox chbCredito;
    @FXML
    private CheckBox chbDevito;
    @FXML
    private CheckBox chbTrans;
    @FXML
    private ComboBox<?> cmbJArdin;
    @FXML
    private ComboBox<?> cmbPrimaria;
    @FXML
    private ComboBox<?> cmbSecundaria;
    @FXML
    private TextArea txaDatosHijo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    

    @FXML
    private void promoverJardin(ActionEvent event) {
    }

    @FXML
    private void promoverPrimaria(ActionEvent event) {
    }
    
}
