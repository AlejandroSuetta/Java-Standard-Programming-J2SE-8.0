package laboclase10;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class LaboClase10 {

    public static void main(String[] args) {
        Path path = Paths.get("data/varios/zips/data.log.txt");
        
        System.out.println(Files.exists(path));
        
        
    }
    
}
