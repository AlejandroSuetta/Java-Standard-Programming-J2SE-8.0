package dominio;

public abstract class Persona {
    private String nombre;
    private String apellido;
    private boolean esMasculino;
    private int estadoCivil;

    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}
    public String getApellido() {return apellido;}
    public void setApellido(String apellido) {this.apellido = apellido;}
    public boolean isEsMasculino() {return esMasculino;}
    public void setEsMasculino(boolean esMasculino) {this.esMasculino = esMasculino;}
    public int getEstadoCivil() {return estadoCivil;}
    public void setEstadoCivil(int estadoCivil) {this.estadoCivil = estadoCivil;}
}