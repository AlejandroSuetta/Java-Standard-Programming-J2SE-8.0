package dominio;

public class Hijo extends Persona{
    private int lugarDeEstudio;

    public Hijo(String nombre, String apellido, boolean esMasculino, int lugarDeEstudio) {
        super();
        this.lugarDeEstudio = lugarDeEstudio;
    }

    public int getLugarDeEstudio() {return lugarDeEstudio;}
    public void setLugarDeEstudio(int lugarDeEstudio) {this.lugarDeEstudio = lugarDeEstudio;}    
}
