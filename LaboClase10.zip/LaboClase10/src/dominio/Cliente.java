package dominio;

import java.util.ArrayList;


public class Cliente extends Persona{
    private ArrayList<Hijo> hijos;
    private boolean formaDePagoAutomatico;
    private boolean formaDePagoTarjetaCredito;
    private boolean formaDePagoTransferenciaBancaria;

    public Cliente(String nombre, String apellido, boolean esMasculino, int estadoCivil, ArrayList<Hijo> hijos, boolean formaDePagoAutomatico, boolean formaDePagoTarjetaCredito, boolean formaDePagoTransferenciaBancaria) {
        super();
        this.hijos = hijos;
        this.formaDePagoAutomatico = formaDePagoAutomatico;
        this.formaDePagoTarjetaCredito = formaDePagoTarjetaCredito;
        this.formaDePagoTransferenciaBancaria = formaDePagoTransferenciaBancaria;
    }

    public ArrayList<Hijo> getHijos() {return hijos;}
    public void setHijos(ArrayList<Hijo> hijos) {this.hijos = hijos;}
    public boolean isFormaDePagoAutomatico() {return formaDePagoAutomatico;}
    public void setFormaDePagoAutomatico(boolean formaDePagoAutomatico) {this.formaDePagoAutomatico = formaDePagoAutomatico;}
    public boolean isFormaDePagoTarjetaCredito() {return formaDePagoTarjetaCredito;}
    public void setFormaDePagoTarjetaCredito(boolean formaDePagoTarjetaCredito) {this.formaDePagoTarjetaCredito = formaDePagoTarjetaCredito;}
    public boolean isFormaDePagoTransferenciaBancaria() {return formaDePagoTransferenciaBancaria;}
    public void setFormaDePagoTransferenciaBancaria(boolean formaDePagoTransferenciaBancaria) {this.formaDePagoTransferenciaBancaria = formaDePagoTransferenciaBancaria;}
}