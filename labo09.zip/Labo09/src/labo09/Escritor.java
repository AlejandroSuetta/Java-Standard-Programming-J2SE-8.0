package labo09;

import java.io.File;
import java.io.FileWriter;
import static java.lang.System.out;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class Escritor {
    private File file;

    public Escritor(File file) {
        this.file = file;
    }
    
    public Escritor(String file) {
        this.file =  new File(file);
    }
    
    public void escribir(String text) {
        try {
            BufferedWriter escritor = new BufferedWriter(new FileWriter (file));
            escritor.write(text);
            escritor.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public String toString() {
        return "Escritor{" + "file=" + file + '}';
    }

    public File getFile() {return file;}
    public void setFile(File file) {this.file = file;}  
}
