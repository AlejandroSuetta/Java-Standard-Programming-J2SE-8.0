package labo09;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector {
    private File file;

    public Lector(File file, String text) {
        this.file = file;
    }
    
    public Lector(String file){
        this.file = new File(file);
    }
    
    public void leer(String file) {
        int car;
        try {
            BufferedReader lector = new BufferedReader(new FileReader(file));
            while((car=lector.read())!=-1) System.out.print((char)car);
        } catch(FileNotFoundException e){
            System.out.println("No se encontro el archivo");
        } catch(IOException e){
            System.out.println("Problemas al leer el archivo.");
        } catch (Exception e) {
            System.out.println("Ocurrio un error no esperado");
            System.out.println(e);
        }
        System.out.println();
    }
            
    @Override
    public String toString() {
        return "Lector{" + "file=" + file + '}';
    }
    
    public File getFile() {return file;}
    public void setFile(File file) {this.file = file;}    
}