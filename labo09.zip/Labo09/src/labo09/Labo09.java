package labo09;

import java.io.File;

public class Labo09 {

    public static void main(String[] args) {
        String file = "res/fuente.txt";
        Lector lector = new Lector(file);
        lector.leer(file);
        
        String file2 = "res/destino.txt";
        Escritor escritor = new Escritor(file2);
        escritor.escribir("Hola, soy Alejandro");
        
        Copiado copiado = new Copiado(file);
        escritor.escribir(copiado.copiar(file));
    }
}