package labo09;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Copiado {
    private File file;

    public Copiado(File file) {
        this.file = file;
    }
    
     public Copiado(String file) {
        this.file = new File(file);
    }
    
    public String copiar(String file) {
        int car;
        StringBuilder copiado = new StringBuilder();
        try {
            FileReader lector  = new FileReader(file);
            while((car=lector.read())!=-1) copiado.append((char)car);
        } catch(FileNotFoundException e){
            System.out.println("No se encontro el archivo");
        } catch(IOException e){
            System.out.println("Problemas al leer el archivo.");
        } catch (Exception e) {
            System.out.println("Ocurrio un error no esperado");
            System.out.println(e);
        }
        return copiado.toString();
    }

    @Override
    public String toString() {
        return "Copiado{" + "file=" + file + '}';
    }

    public File getFile() {return file;}
    public void setFile(File file) {this.file = file;}
}
