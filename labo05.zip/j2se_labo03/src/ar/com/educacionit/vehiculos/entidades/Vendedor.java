package ar.com.educacionit.vehiculos.entidades;

import ar.com.educacionit.base.entidades.Persona;

public class Vendedor extends Persona{
    private int cantAutosVendidos;

    public int getCantAutosVendidos()                       { return cantAutosVendidos; }
    public void setCantAutosVendidos(int cantAutosVendidos) { this.cantAutosVendidos = cantAutosVendidos; }

    public Vendedor(int cantAutosVendidos, String nombre, String apellido, String numerodedocumento) {
        super(nombre, apellido, numerodedocumento);
        this.cantAutosVendidos = cantAutosVendidos;
    }

    @Override
    public String toString() {
        return super.toString() + "Vendedor{" + "cantAutosVendidos=" + cantAutosVendidos + '}';
    }    
}
